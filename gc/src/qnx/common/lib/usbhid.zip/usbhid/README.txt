Library for accessing USB human interface devices, like joysticks.

Used for manual driving by remote control.

John Nagle
Team Overbot
June, 2004.