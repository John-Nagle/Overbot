/*
 * Copyright  2000, QNX Software Systems Ltd.  All Rights Reserved
 *
 * This source code has been published by QNX Software Systems Ltd.
 * (QSSL).  However, any use, reproduction, modification, distribution
 * or transfer of this software, or any software which includes or is
 * based upon any of this code, is only permitted under the terms of
 * the QNX Open Community License version 1.0 (see licensing.qnx.com
 * for details) or as otherwise expressly authorized by a written license
 * agreement from QSSL.  For more information, please email licensing@qnx.com.
 */


/*
 * h_client.c
 *
 * Sample HID client
 *
 */

#include "h_client.h"

client_ctrl_t				ClientCtrl;

int verbosity = 0;
void test_signal_handler( int signo )
{
	int 				status;
	client_report_t		*rep, *nrep;

    signo = signo;
    for( rep = ClientCtrl.reports ; rep ; rep = nrep ) {
        nrep = rep->next;
		if( status = hidd_report_detach( rep->report ) ) {
   		}
	}
	
    hidd_disconnect( ClientCtrl.connection );
    _exit( 0 );
}

void show_buttons ( _uint16 *buf, _uint16 num_press, char *msg )
{
	int 	x;

	if ( num_press ) {
		fprintf( stderr,"%s", msg );
		for ( x = 0 ; x < num_press ; x++ ) 
			fprintf( stderr,"0x%x ", buf[x] );
		fprintf( stderr,"\n");
	}
}

int handle_mouse( client_report_t *report, void *report_data )
{
	_uint32					xval, yval, wheel;
	_uint16					num_press;
	_uint16 				*tptr;

	hidd_get_usage_value( report->instance, NULL, 1, HIDD_USAGE_X, report_data, &xval);
	hidd_get_usage_value( report->instance, NULL, 1, HIDD_USAGE_Y, report_data, &yval);

	/* if you want a wheel mouse */
	hidd_get_usage_value( report->instance, NULL, 1, HIDD_USAGE_WHEEL, report_data, &wheel);

	fprintf( stderr, "%s x=%d y=%d wheel=%d\n", (report->data_flags & COORDINATES_ABSOLUTE ) ? "Absolute" : "Relative", xval, yval, wheel);	

	num_press = num_press = report->max_but;;

	/* get button data from report */
	hidd_get_buttons( report->instance, NULL, HIDD_PAGE_BUTTONS, report_data, report->cbtnbuf, &num_press); // get buttons currently pressed

	hidd_button_list_diff( report->cbtnbuf, report->pbtnbuf, report->rbtnbuf, &num_press);
	show_buttons( report->rbtnbuf, num_press, "Buttons Pressed :" );

	// get buttons released
	num_press = num_press = report->max_but;;
	hidd_button_list_diff( report->pbtnbuf, report->cbtnbuf, report->rbtnbuf, &num_press);
	show_buttons( report->rbtnbuf, num_press, "Buttons Released :" );

	// get buttons held
	num_press = num_press = report->max_but;;
	hidd_button_list_same( report->cbtnbuf, report->pbtnbuf, report->rbtnbuf, &num_press);
	show_buttons( report->rbtnbuf, num_press, "Buttons Held :" );

	//exchange prev and current ptrs to save copying data
	tptr = report->pbtnbuf;
	report->pbtnbuf = report->cbtnbuf;
	report->cbtnbuf = tptr;

	return( EOK );
}

void hid_report( struct hidd_connection *connection, struct hidd_report *report, void *report_data,
		 _uint32 report_len, _uint32 flags, void *user)
{
	client_report_t			*c_report = user;
	_uint16					usage_page, usage;
	struct hidd_collection	*collection;

	/* you could also store this info with the report */
	hidd_report_collection( c_report->instance, &collection );
	hidd_collection_usage( collection, &usage_page, &usage); 	

	switch ( usage_page ) {
		case HIDD_PAGE_DESKTOP :
			switch( usage ) {
				case HIDD_USAGE_KEYBOARD :
					break;	
				case HIDD_USAGE_MOUSE	:		
				case HIDD_USAGE_POINTER	:		
						handle_mouse( c_report, report_data );
					break;
			}
			break;
		case HIDD_PAGE_CONSUMER :
			break;
		case HIDD_PAGE_DIGITIZER :
			break;

		default :
			break;		
	}
}

int get_data_properties( struct hidd_report_instance *report_instance, client_report_t *client_report )
{
	hidd_report_props_t			*report_props;
	_uint16						len;
	int							x;

	hidd_get_num_props( report_instance, &len );
	report_props = (hidd_report_props_t *) malloc( len * sizeof(hidd_report_props_t) );

	hidd_get_report_props( report_instance, report_props, &len);
	
	//look for x,y and see if data is relative or absolute, you may want to store 
	// some of the other information as well

	for ( x = 0 ; x < len ; x++ ) {
		if ( report_props[x].usage_min == HIDD_USAGE_X || report_props[x].usage_min == HIDD_USAGE_Y )
			if ( !(report_props[x].data_properties &  HID_FIELD_RELATIVE ) )
				client_report->data_flags |= COORDINATES_ABSOLUTE;
	}
	return( EOK );
}

void hid_insertion( struct hidd_connection *connection, hidd_device_instance_t *device_instance)
{
	struct hidd_report_instance 	*report_instance;
	struct hidd_report				*report;
	client_report_t					*client_report = NULL;
	int								status;
	_uint16							max_but;
	int								x;
	struct hidd_collection			**hidd_collections, **hidd_mcollections;
	_uint16							num_col, num_mcol;
	_uint16							usage_page, usage;

	fprintf( stderr," Got insertion\n");

	// find what reports we are interested in for this device and
	// register for them.

	/* get root level collections */
	hidd_get_collections( device_instance, NULL, &hidd_collections, &num_col);

	for ( x = 0; x < num_col; x++ ) {
		hidd_collection_usage( hidd_collections[x], &usage_page, &usage);
		switch(	usage_page ) {

			case HIDD_PAGE_DESKTOP :
				switch ( usage ) {
					case HIDD_USAGE_JOYSTICK :
						break;
					case HIDD_USAGE_KEYBOARD :
						break;
					case HIDD_USAGE_MOUSE :
						/* get pointer collection */	
						if ( hidd_get_report_instance( hidd_collections[0], 0 , HID_INPUT_REPORT, &report_instance ) == EOK ) {
							hidd_num_buttons( report_instance, &max_but );
							if( ( status = hidd_report_attach( connection, device_instance, report_instance,
								 0, sizeof(client_report_t) + ( (max_but *3) * sizeof(_int32) ) , &report ) ) == EOK ) {
								client_report					= hidd_report_extra( report );
								client_report->report			= report;
								client_report->instance			= report_instance;
								client_report->max_but			= max_but;
								// set buffer pointers : this are pointer into extra area allocated with the attach
								client_report->cbtnbuf          = (_uint16 *) (client_report + 1); // setup pointer  to button data
								client_report->pbtnbuf          = client_report->cbtnbuf + ( (max_but) * sizeof(_int32) ); // setup
								client_report->rbtnbuf          = client_report->pbtnbuf + ( (max_but) * sizeof(_int32) ); // setup	client_report->cbtnbuf 			= (_uint16 *)(client_report + 1); // setup pointer  to button data
								get_data_properties( report_instance, client_report );
							}
						}

						hidd_get_collections( NULL, hidd_collections[x], &hidd_mcollections, &num_mcol);
						if ( num_col &&  hidd_get_report_instance( hidd_mcollections[0], 0 , HID_INPUT_REPORT, &report_instance ) == EOK ) {
							hidd_num_buttons( report_instance, &max_but );
							if( ( status = hidd_report_attach( connection, device_instance, report_instance,
								 0, sizeof(client_report_t) + ( (max_but *3) * sizeof(_int32) ) , &report ) ) == EOK ) {
								client_report					= hidd_report_extra( report );
								client_report->report			= report;
								client_report->instance			= report_instance;
								client_report->max_but			= max_but;

								// set buffer pointers : this are pointer into extra area allocated with the attach
								client_report->cbtnbuf          = (_uint16 *) (client_report + 1); // setup pointer  to button data
								client_report->pbtnbuf          = client_report->cbtnbuf + ( (max_but) * sizeof(_int32) ); // setup
								client_report->rbtnbuf          = client_report->pbtnbuf + ( (max_but) * sizeof(_int32) ); // setup
								get_data_properties( report_instance, client_report );
							}
						}

					break;
				}	
				break;
			case HIDD_PAGE_CONSUMER :
				break;

			case HIDD_PAGE_DIGITIZER :
			break;
		}
	}
}

void hid_removal( struct hidd_connection *connection, hidd_device_instance_t *instance )
{
	fprintf( stderr," Got device removal\n");
	
	/* detach from all reports you have register on this device */
	hidd_reports_detach( connection, instance);
}

int main(int argc, char *argv[]) 
{
	hidd_device_ident_t        interest = {
                            HIDD_CONNECT_WILDCARD,
                            HIDD_CONNECT_WILDCARD,
                            HIDD_CONNECT_WILDCARD,
							};

	hidd_funcs_t            funcs = { _HIDDI_NFUNCS, hid_insertion, hid_removal, hid_report, NULL };
	hidd_connect_parm_t     parm = { NULL, HID_VERSION, HIDD_VERSION, 0, 0, 0, 0, HIDD_CONNECT_WAIT };
	int						status, opt;

	while( ( opt = getopt( argc, argv, "s:" ) ) != -1 ) {
		switch( opt ) {
			case 's':
				parm.path = optarg;
				break;
			default :
				break;
		}
	}

	parm.funcs = &funcs;
	parm.device_ident = &interest;

	signal( SIGHUP, SIG_IGN );
	signal( SIGPWR, SIG_IGN );
	signal( SIGTERM, test_signal_handler );
	signal( SIGKILL, test_signal_handler );

	if( ( status = hidd_connect( &parm, &ClientCtrl.connection ) ) != EOK ) {
	    fprintf( stderr, "Can't connect to HID Server %s\n", strerror( status ) );
		return( 1 );
	}
	while ( 1 ) {

		sleep(10 );
	}

	wait( NULL );

	return( EXIT_SUCCESS );
}

