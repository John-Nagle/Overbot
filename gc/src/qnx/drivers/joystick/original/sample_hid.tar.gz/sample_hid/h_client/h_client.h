/*
 * Copyright  2000, QNX Software Systems Ltd.  All Rights Reserved
 *
 * This source code has been published by QNX Software Systems Ltd.
 * (QSSL).  However, any use, reproduction, modification, distribution
 * or transfer of this software, or any software which includes or is
 * based upon any of this code, is only permitted under the terms of
 * the QNX Open Community License version 1.0 (see licensing.qnx.com
 * for details) or as otherwise expressly authorized by a written license
 * agreement from QSSL.  For more information, please email licensing@qnx.com.
 */

/*
 * h_client.h
 *
 * Sample HID client
 *
 */

#include <share.h>
#include <errno.h>
#include <stdio.h>
#include <atomic.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <termios.h>
#include <gulliver.h>
#include <sys/queue.h>
//#include <devi.h>
//#include <storage.h>
//#include <keymap.h>

#include <sys/hiddi.h>
#include <sys/hidut.h>

// from HID usage tables for  keyboard
#define HIDD_USAGE_KEY_CAPS_LOCK		0x39
#define HIDD_USAGE_KEY_NUM_LOCK			0x53
#define HIDD_USAGE_KEY_SCROLL_LOCK		0x47


// local defines to keep track of toggle state
#define CAPS_LOCK_ON					0x01
#define NUM_LOCK_ON						0x02
#define SCROLL_LOCK_ON					0x04

// defines for data_flags
#define COORDINATES_ABSOLUTE			0x01

typedef struct client_report {
	struct	client_report			*next; 			// link
    struct hidd_report_instance     *instance;		// pointer report instance from insertion
	struct hidd_report      		*report;		// registration handle
	_uint16							max_but;		// max buttons returned in a report
	_uint16							report_len;		// max report length
	_uint16							*cbtnbuf;		// current button buffer
	_uint16							*pbtnbuf;		// previous button buffer
	_uint16							*rbtnbuf;		// repeated button buffer
    _uint32                         *cvalues;		// current value
    _uint32                         *pvalues;		// previous value
	struct	client_report			*output_report; //stores pointer to output report
    _uint32                         status;
    _uint32                         led_state;		// store led state
	_uint32							data_flags;
} client_report_t;



typedef struct _client_ctrl {
    struct hidd_connection          *connection;
	client_report_t					*reports;
    _uint32                         verbose;
} client_ctrl_t;

